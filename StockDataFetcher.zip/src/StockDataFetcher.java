

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.Properties;
import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;

public class StockDataFetcher
{
	static Logger logger = Logger.getLogger("sdf");
	static String authToken = null; 
	static ArrayList<FileDownLoadParams> packageDeliveryIdList = new ArrayList<FileDownLoadParams>();
	static ArrayList<String> subscriptionIdList = new ArrayList<String>();
	final static Properties prop = new Properties();
	static Calendar cal = Calendar.getInstance();
	static String startTime="";
	static ArrayList<ReportLineVenueList> venueLines = new ArrayList<ReportLineVenueList>();
	static ArrayList<FileDownLoadParams> fileListLines = new ArrayList<FileDownLoadParams>();
	static PrintWriter writer;

	public static void main(String[] args)
	{
		try
		{
			Runtime.getRuntime().addShutdownHook(new Thread()
			{
				@Override
				public void run()
				{
					logger.info("Application exiting.Performing clean up");
				}
			});
			startTime=cal.getTime().toString();
			logger.info("Starting Application..");
			//Read config data from config file
			if(args.length == 1)
			{
				logger.info("Using config file:"+args[0]);
				prop.load(new FileInputStream(args[0]));
				logger.info("Parsed Property File");
				logger.info("Checking environment setup..");
				if(checkConfig()) //This is to ensure that the data directories and required parameters are set in the config file
				{
					logger.info("Environment Check OK..");
					if(authToken == null)
						getAuthToken(); //Authorization token is created at this stage and then reused for subsequent calls within the same program
					getUserPackages(); //get the list of Venue files to download
					for(int i=0;i<subscriptionIdList.size();i++)
					{
						getFilesForDateRange(subscriptionIdList.get(i)); //All files for that particular subscription id and date range (T-1) are fetched 
					}
					initializeReport(startTime,Calendar.getInstance().getTime().toString()); //Report to write the details of the job
					if(venueLines.size() > 0)
					{
						printRowVenueHeader();
						Iterator<ReportLineVenueList> iterator = venueLines.iterator();
						int i=1;
						while (iterator.hasNext()){
							ReportLineVenueList item = iterator.next();
							printRowVenue(i,item.getPackageName(),item.getSubscriptionId());
							i++;
						}
						printRowVenueFooter();
					}
					writer.flush();
					if(fileListLines.size() > 0)
					{
						printRowFileParamHeader();
						int i=1;
						Iterator<FileDownLoadParams> iterator = fileListLines.iterator();
						while (iterator.hasNext()){
							FileDownLoadParams item = iterator.next();
							printRowFileParam(i,item.getFileName(),item.getSubscriptionId(),item.getReleaseDateTime(),item.getFileSize(),item.getFrequency(),item.getChecksum());
							i++;
						}
						printRowFileParamFooter();
					}
					writer.flush();
					for(int i=0;i<packageDeliveryIdList.size();i++)
					{
						downloadFileByPackageDeliveryId(packageDeliveryIdList.get(i));
					}
					writer.close();
				}
			}
			else
			{
				logger.fatal("Usage:StockDataFetcher [ConfigFile]");
				System.exit(-1);
			}

		}
		catch (IOException ex) {
			ex.printStackTrace();
		}
		catch ( Exception e)
		{
			e.printStackTrace();
		}
	}
	//Parse JSON response in this function
	public static JSONArray parseResponseJSON(String json,Integer type) throws ApplicationException
	{
		String result=null;
		try {
			JSONParser parser = new JSONParser();
			Object resultObject = parser.parse(json);

			if (resultObject instanceof JSONObject) {
				JSONObject obj =(JSONObject)resultObject;
				result = obj.get("value").toString();
				if(type==1)
				{
					authToken=result;
				}
				if(type==2)
				{	
					JSONArray msg = (JSONArray) obj.get("value");
					return msg;
				}
			}
			else
				throw new ApplicationException("Invalid Datatype returned for request");

		} catch (Exception e) {
			// TODO: handle exception
		}
		return null;
	}	
	//Pass the correct headers to get Authorization Token
	public static void getAuthToken()
	{
		String body = "{ \"Credentials\": { \"Username\": \"" + prop.getProperty("username") + "\", \"Password\": \"" + prop.getProperty("password") + "\"}}";
		try {
			parseResponseJSON(httpPost(prop.getProperty("authUrl"),body),1);
			logger.info("Obtained Authorization token successfully");
			logger.debug("Auth Token:"+authToken);
		} catch (ApplicationException e) {
			logger.error(e.getMessage());
		}
	}
	//Get available venues for user
	public static void getUserPackages()
	{
		JSONArray respArray = new JSONArray();
		try {
			respArray = parseResponseJSON(httpGet(prop.getProperty("venuePackageIdUrl"),false,null),2);
			logger.info("Getting list of Venues");
			//Each venue has a subscription id, which is then used to determine the list of files available. This subscription is stored in a list and used later
			for(int i=0;i < respArray.size();i++)
			{
				JSONObject respObj = new JSONObject();
				respObj = (JSONObject) respArray.get(i);
				ReportLineVenueList venueList = new ReportLineVenueList(respObj.get("UserPackageId").toString(),respObj.get("PackageId").toString(),respObj.get("PackageName").toString(),respObj.get("SubscriptionId").toString(),respObj.get("SubscriptionName").toString());
				venueLines.add(venueList);
				if(!subscriptionIdList.contains(respObj.get("SubscriptionId")))
					subscriptionIdList.add(respObj.get("SubscriptionId").toString());
			}
			logger.info("Venue List Obtained : "+respArray.size());

		} catch (ApplicationException e) {
			logger.error(e.getMessage());
		}
	}
	private static void getFilesForDateRange(String string) {
		JSONArray respArray = new JSONArray();
		String url = prop.getProperty("fileListForDateRange");

		LocalDate.now(ZoneId.of(prop.getProperty("timeZone")));

		url = url.replaceAll("<SUBSCR_ID>", string);
		url = url.replaceAll("<FROM_DATE>", LocalDate.now().minusDays(1L).toString()+"T00:00:01.000Z");
		//url = url.replaceAll("<FROM_DATE>", LocalDate.now().minusDays(-1L).toString()+"T00:00:01.000Z");
		url = url.replaceAll("<TO_DATE>", LocalDate.now().toString()+"T00:00:01.000Z");
		//url = url.replaceAll("<TO_DATE>", LocalDate.now().minusDays(-2L).toString()+"T00:00:01.000Z");
		logger.info("Obtaining files between " + LocalDate.now().minusDays(1L).toString() + " and " + LocalDate.now().toString());
		logger.debug("URL " + url);

		try {
			respArray = parseResponseJSON(httpGet(url,false,null),2);
			logger.info("List of Files to download");
			for(int i=0;i < respArray.size();i++)
			{
				JSONObject respObj = new JSONObject();
				respObj = (JSONObject) respArray.get(i);
				FileDownLoadParams fileParam = new FileDownLoadParams(respObj.get("PackageDeliveryId").toString(),respObj.get("UserPackageId").toString(),respObj.get("SubscriptionId").toString(),respObj.get("Name").toString(),respObj.get("ReleaseDateTime").toString(),(Long) respObj.get("FileSizeBytes"),respObj.get("Frequency").toString(),respObj.get("ContentMd5").toString());
				fileListLines.add(fileParam);
				if(!packageDeliveryIdList.contains(fileParam))
					packageDeliveryIdList.add(fileParam);
			}
			logger.info("Files to download : "+respArray.size());

		} catch (ApplicationException e) {
			logger.error(e.getMessage());
		}

	}
	//Files are donwloaded here
	private static void downloadFileByPackageDeliveryId(FileDownLoadParams params) {
		String url = prop.getProperty("fileDownloadUrl");
		url = url.replaceAll("<PKG_DELIVERY_ID>", params.getPackageDeliveryId());
		logger.debug("File URL" + url);
		logger.info("Downloading File " + params.getFileName());

		try {
			httpGet(url,true,params.getFileName());
		} catch (ApplicationException e) {
			logger.error(e.getMessage());
		} 	
	}
	public static String httpPost(String url, String body) throws ApplicationException {

		String response = null;
		try (CloseableHttpClient httpClient = HttpClientBuilder.create().build()) {
			HttpPost request = new HttpPost(url);
			request.addHeader("content-type", "application/json");
			StringEntity params = new StringEntity(body);
			request.setEntity(params);
			HttpResponse result = httpClient.execute(request);
			if(result.getStatusLine().toString().contains("200"))
				response = EntityUtils.toString(result.getEntity(), "UTF-8");
			else
				throw new ApplicationException("Error during HttpPost Call.Please make sure the correct URL is being called.");

		} catch (IOException ex) {
		}
		return response;
	}
	public static String httpGet(String url,Boolean isDownload,String fileName) throws ApplicationException {

		String returnData = null;
		String dirPrefix = null;
		OutputStream out = null;
		if(isDownload)
			dirPrefix = fileName.substring(0,3);

		try (CloseableHttpClient httpClient = HttpClientBuilder.create().build()) {
			if(isDownload)
			{
				new File(prop.getProperty("data_download_dir")+"/"+ dirPrefix).mkdirs();
				out = new FileOutputStream(prop.getProperty("data_download_dir")+"/"+ dirPrefix + "/" + fileName);
			}
			HttpGet request = new HttpGet(url);
			request.addHeader("content-type", "application/json");
			request.addHeader("Authorization", "Token "+authToken);
			
			CloseableHttpResponse response = httpClient.execute(request);
			if(response.getStatusLine().toString().contains("200"))
			{	
				if(!isDownload)
				{
					returnData = EntityUtils.toString(response.getEntity(), "UTF-8");
				}
				else
				{
					try 
					{
						HttpEntity entity = response.getEntity();
						entity.writeTo(out);
					} 
					finally {
						response.close();
						out.close();
					}

				}
			}
			else
			{
				out.close();
				throw new ApplicationException("Error during HttpGet Call.Please make sure the correct URL is being called");
			}


		} catch (IOException ex) {
			logger.error(ex.getMessage());
		}
		return returnData;
	}
	public static boolean checkConfig()
	{
		if(checkDirectory("data_download_dir")
				&& checkDirectory("reports_dir") 
				&& checkConfigParam("username")
				&& checkConfigParam("password")
				&& checkConfigParam("authUrl")
				&& checkConfigParam("venuePackageIdUrl")
				&& checkConfigParam("fileListForDateRange")
				&& checkConfigParam("fileDownloadUrl"))
			return true;
		else
			return false;
	}
	public static boolean checkDirectory(String dirName)
	{
		if(prop.getProperty(dirName)==null)
		{
			logger.fatal("Property "+dirName+" has not been defined in the config file. Cannot proceed");
			System.exit(-1);
		}
		dirName=prop.getProperty(dirName);
		logger.info("Checking if path " + dirName + " exists.");
		File f = new File(dirName);
		if(!f.exists() && !f.isDirectory())
		{
			logger.warn(dirName + " does not exist.Attempting to create");
			if(!f.mkdir())
			{
				logger.fatal("Could not create directory " + dirName + ". Please check if you have the required permissions. Program will now exit");
				System.exit(-1);
				return false;
			}
			else
				logger.info(dirName + " created successfuly.");
		}
		else
		{
			logger.info(dirName + " already exists.OK.");
		}
		return true;
	}
	public static boolean checkConfigParam(String paramName)
	{
		if(prop.getProperty(paramName)==null)
		{
			logger.fatal("Property "+paramName+" has not been defined in the config file. Cannot proceed");
			System.exit(-1);
		}
		return true;
	}
	public static void initializeReport(String startTime, String endTime) {
		DateFormat dateFormat = new SimpleDateFormat("DDMMYYYY_HHmmss");
		Calendar cal = Calendar.getInstance();
		try {
			writer = new PrintWriter(prop.getProperty("reports_dir")+"/ReutersStockFeedFetch_"+dateFormat.format(cal.getTime())+".rpt", "UTF-8");
			writer.println("**************************************************** Reuters Stock Feed Fetcher ***************************************************");
			writer.println("Program Start Time :"+startTime);
			writer.println("Program End Time   :"+endTime);
			writer.println("***********************************************************************************************************************************");
			writer.println(" ");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}
	static void printRowVenueHeader() {
		writer.println("List Of Venues Available for Subscription");
		writer.println(" ");
		writer.printf("%-5s %-60s %-25s%n", "-----", "-----------------------------------------------------------","-------------------------");
		writer.printf("%-5s %-60s %-25s%n", "S.No", "Package Name","Subscription Id");
		writer.printf("%-5s %-60s %-25s%n", "-----", "-----------------------------------------------------------","-------------------------");
	}
	static void printRowVenueFooter() {
		writer.printf("%-5s %-60s %-25s%n", "-----", "-----------------------------------------------------------","-------------------------");
		writer.println(" ");
	}
	static void printRowVenue(Object obj1,Object obj2,Object obj3) {
		writer.printf("%-5s %-60s %-25s%n", obj1.toString(), obj2.toString(),obj3.toString());
	}
	static void printRowFileParamHeader() {
		writer.println(" ");
		writer.println("List Of Files Available for Download");
		writer.println(" ");
		writer.printf("%-5s %-60s %-25s %-25s %-15s %-10s %-35s%n", "-----", "------------------------------------------------------------","-------------------------","-------------------------","---------------","----------","-----------------------------------");
		writer.printf("%-5s %-60s %-25s %-25s %-15s %-10s %-35s%n", "S.No", "File Name","Subscription Id","Release Date/Time","FileSize(Bytes)","Frequency","MD5 Checksum");
		writer.printf("%-5s %-60s %-25s %-25s %-15s %-10s %-35s%n", "-----", "------------------------------------------------------------","-------------------------","-------------------------","---------------","----------","-----------------------------------");
	}
	static void printRowFileParamFooter() {
		writer.printf("%-5s %-60s %-25s %-25s %-15s %-10s %-35s%n", "-----", "------------------------------------------------------------","-------------------------","-------------------------","---------------","----------","-----------------------------------");
		writer.println(" ");
	}
	static void printRowFileParam(Object obj1,Object obj2,Object obj3,Object obj4,Object obj5,Object obj6,Object obj7) {
		writer.printf("%-5s %-60s %-25s %-25s %-15s %-10s %-35s%n", obj1.toString(), obj2.toString(),obj3.toString(),obj4.toString(),obj5.toString(),obj6.toString(),obj7.toString());
	}
	static void printRow(Object obj1,Object obj2,Object obj3,Object obj4,Object obj5,Object obj6) {
		writer.printf("%-6s %-60s %-30s %-10s %-10s %-80s%n", obj1.toString(), obj2.toString(),obj3.toString(),obj4.toString(),obj5.toString(),obj6.toString());
	}
	static void printRow(Object count, String text1,  Object text2, String text3) {
		writer.printf("%-6s %-50s %-10s %-50s%n", count.toString(), text1, text2.toString(), text3);
		writer.flush();
	}

}